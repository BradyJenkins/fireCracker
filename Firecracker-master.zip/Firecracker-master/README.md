# Firecracker
Throw bricks and let the firecrackers explode! Happy new year!

## Version 0.1.0 - Cool sounds + Particles
Simple bug fix with the config
Flame particles when you throw it
FizzSound when its thrown
Now less lag and faster
Correct name when selected

## Download
Download the latest version here:
http://5.175.226.133/de_DE/plugins/Firecracker.php

## Notes
This plugin was coded by @thebigsmileXD of the Imagical Corporation. When using it on your server or when editing it, please give all the credit to him. Thanks, and have a happy new year!
